﻿sap.ui.jsfragment("com.loginapp.fragments.StudentDetailsBasicData", {
   /* createContent: function (evt) {
    	alert("?");
    }*/
});